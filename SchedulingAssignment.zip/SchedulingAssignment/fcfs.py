arrival_time = []
burst_time = []
waiting_time = [0]
finish_time = []
index=0
index1=0
processes=0

print "Enter number of processes:"
number = input()

print "Enter arrival times:"
for x in range(number):
    print 'for P [',(x+1),']:'
    arrival_time.append(input())

print 'Enter burst time for processes:'
for x in range(number):
    print 'for P [',(x+1),']:'
    burst_time.append(input())

	


for x in range(number):
	a = burst_time[x] + arrival_time[x] + waiting_time[x]
	finish_time.append(a)
	if x<number-1:
		z = finish_time[x] - arrival_time[x+1]
		waiting_time.append(z)


print "Waiting time is: " , waiting_time

print "Finish time is: " , finish_time

calculate_wait = 0.0
for x in range (number):
  c = waiting_time[x]
  calculate_wait +=c
print "Average waiting time is: " , calculate_wait/number





